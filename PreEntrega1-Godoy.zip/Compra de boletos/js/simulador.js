const precioMayor = 50
const precioMenor = 25

function viajePrecioTotal(){
    let adultos = prompt("¿Cuantos adultos viajarán?")
    let menores = prompt("¿Hay menores de edad? ¿Cuántos?")
    let precioTotal
    if (adultos !== 0 && menores !== 0){
        let precioTotal = ((adultos * precioMayor)+(menores * precioMenor))
        console.log("El costo de tus boletos es: $" + precioTotal)
        let pagoMeses = prompt("¿En cuantas cuotas deseas realizar al pago ?")
        console.log("El costo de cada cuota es el siguiente:")
        if(pagoMeses!== 1){
            for (let i = 1; i <= pagoMeses; i++){
            console.log("Cuota número " + i + ": $" + (precioTotal / pagoMeses).toFixed(2))
            }
            console.log("Muchas gracias por elegirnos!")
        } else {
            console.log("Has decidido pagar al contado, Muchas gracias por elegirnos!")
        }
    } else {
        console.warn("Hubo un error, por favor vuelve a intentarlo")
    }   
}